<?php $__env->startSection('content'); ?>
  <div class="page-header">
    <h3 class="page-title">
			<span class="page-title-icon bg-gradient-primary text-white me-2">
				<i class="mdi mdi-flag"></i>
			</span>
      <?php echo e($page_title); ?>

    </h3>
    <a href="<?php echo e(route('admin.mentor_week.index')); ?>" class="btn btn-dark">Вернуться к списку</a>
  </div>
  <div class="row">
    <div class="col-md-12 grid-margin">
      <?php echo $__env->make('layouts.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div class="card">
        <div class="card-body">
          <form action="<?php echo e(route('admin.mentor_week.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
              <label>Для ментора: *</label>
              <select name="mentor_id" class="select2 form-control-sm form-control">
                <option value="">Выберите</option>
                <?php if($mentors->count()): ?>
                  <?php $__currentLoopData = $mentors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mentor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($mentor->id); ?>" <?php if($mentor->id == old('mentor_id', $mentor->mentor_id)): ?> selected <?php endif; ?>><?php echo e($mentor->last_name); ?> <?php echo e($mentor->first_name); ?> <?php echo e($mentor->surname); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
              </select>
            </div>
            <div class="form-group">
              <label>Для категории: *</label>
              <select name="category_id" class="select2 form-control-sm form-control">
                <option value="">Выберите</option>
                <?php if($categories->count()): ?>
                  <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <optgroup label="<?php echo e($parent->name); ?>">
                      <?php $__currentLoopData = $parent->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>" <?php if($category->id == old('category_id', null)): ?> selected <?php endif; ?>><?php echo e($category->name); ?> </option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </optgroup>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
              </select>
            </div>
            <div class="form-group">
              <label>Статус: *</label>
              <div class="form-check">
                <label class="form-check-label">
                  <input id="verified0" type="radio" name="is_active" value="0" class="form-check-input" <?php if(!old('is_active')): ?> checked <?php endif; ?>/>
                  Не активный
                  <i class="input-helper"></i>
                </label>
              </div>
              <div class="form-check">
                <label class="form-check-label">
                  <input id="verified1" type="radio" name="is_active" value="1" class="form-check-input" <?php if(old('is_active')): ?> checked <?php endif; ?>/>
                  Активный
                  <i class="input-helper"></i>
                </label>
              </div>
            </div>
            <div class="form-group">
              <label>Дата начала: *</label>
              <input type="date" name="date_start" value="<?php echo e(old('date_start', '')); ?>" class="form-control" />
            </div>
            <div class="form-group">
              <label>Время начала: *</label>
              <input type="time" name="time_start" value="<?php echo e(old('time_start', '')); ?>" class="form-control" />
            </div>
            <div class="form-group">
              <label>Дата конца: *</label>
              <input type="date" name="date_end" value="<?php echo e(old('date_end', '')); ?>" class="form-control" />
            </div>
            <div class="form-group">
              <label>Время конца: *</label>
              <input type="time" name="time_end" value="<?php echo e(old('time_end', '')); ?>" class="form-control" />
            </div>
          
            <div class="form-group">
<!--              <button class="btn btn-primary" type="submit" name="return" value="1">Сохранить и выйти</button>-->
              <button class="btn btn-success" type="submit">Сохранить</button>
              <a href="<?php echo e(route('admin.mentor_week.index')); ?>" class="btn btn-danger">Выйти без сохранения</a>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/i/indesiv4/indesiv4.beget.tech/public_html/resources/views/admin/mentor_week/add.blade.php ENDPATH**/ ?>