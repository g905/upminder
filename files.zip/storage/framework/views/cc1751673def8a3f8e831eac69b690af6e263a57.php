

<?php $__env->startSection('content'); ?>
  <div class="page-header">
    <h3 class="page-title">
			<span class="page-title-icon bg-gradient-primary text-white me-2">
				<i class="mdi mdi-home"></i>
			</span>
      <?php echo e($page_title); ?>

    </h3>
    <a href="<?php echo e(route('admin.lessons.add', 0)); ?>" class="btn btn-success">Добавить</a>
  </div>
  
  <div class="row">
    <div class="col-md-12 grid-margin">
      <?php if(session('error')): ?>
        <div class="alert alert-warning"><?php echo e(session('error')); ?></div>
      <?php endif; ?>
      <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
      <?php endif; ?>
      <div class="card">
        <div class="card-body table">
          <div class="table-responsive">
            <table class="table">
              <thead>
                <th width="36px"><input type="checkbox" class="select_all" /></th>
                <th width="36px">ID</th>
                <th width="250px">Ментор</th>
                <th width="250px">Дата начала</th>
                <th width="250px">Дата конца</th>
                <th width="200px">Описание</th>
                <th width="200px">Стоимость</th>
                <th width="200px">Клиент</th>
                <th width="200px" align="right">Действия</th>
              </thead>
              <tbody>
                <?php if($lessons->count()): ?>
                  <?php $__currentLoopData = $lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><input type="checkbox" name="ids[]" value="<?php echo e($lesson->id); ?>" /></td>
                      <td><?php echo e($lesson->id); ?></td>
                      <td><?php echo e($lesson->mentor->last_name); ?> <?php echo e($lesson->mentor->first_name); ?></td>
                      <td><?php echo e($lesson->date_start); ?></td>
                      <td><?php echo e($lesson->date_end); ?></td>
                      <td><?php echo e(Str::limit($lesson->description, 30)); ?></td>
                      <td><?php echo e($lesson->price); ?></td>
                      <td><?php echo e($lesson->client); ?></td>
          
                      <td align="right">
                        <a href="<?php echo e(route('admin.lessons.edit', $lesson->id)); ?>" class="badge badge-info"><i class="remove mdi mdi-pencil"></i></a>
                        <a href="<?php echo e(route('admin.lessons.delete', [$lesson->id])); ?>" data-confirm="Удалить занятие?" class="confirm badge badge-danger"><i class="remove mdi mdi-close-circle-outline"></i></a>
                      </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                  <tr>
                    <td colspan="4">Нет информации</td>
                  </tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\indesiv4.loc\resources\views/admin/lessons/index.blade.php ENDPATH**/ ?>