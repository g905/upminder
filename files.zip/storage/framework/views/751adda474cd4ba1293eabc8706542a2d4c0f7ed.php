<?php $__env->startSection('content'); ?>
  <div class="page-header">
    <h3 class="page-title">
			<span class="page-title-icon bg-gradient-primary text-white me-2">
				<i class="mdi mdi-flag"></i>
			</span>
      <?php echo e($page_title); ?>

    </h3>
    <a href="<?php echo e(route('admin_task_type_form', 0)); ?>" class="btn btn-success">Добавить</a>
  </div>
  <div class="btn-group">
    <button type="button" data-card="filters" class="btn btn-small btn-primary btn-tabs show_card <?php if($filters['applied']): ?> active <?php endif; ?>">Фильтрация</button>
  </div>
  <div class="row">
    <div class="col-md-12 grid-margin">
      <div class="card">
        <form action="<?php echo e(route('admin_task_type_list')); ?>">
          <div class="card-body dynamic filters <?php if(!$filters['applied']): ?> filter_hide <?php else: ?> shown <?php endif; ?>">
            <div class="row">
              <div class="col-md-3">
                <div class="form-group">
                  <label>Категория:</label>
                  <select name="filters[category_id]" class="select2 form-control-sm form-control">
                    <option value="">Все категории</option>
                    <?php if($categories->count()): ?>
                      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>" <?php if($filters['category_id'] == $category->id): ?> selected <?php endif; ?>><?php echo e($category->name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                  </select>
                </div>
              </div>
              <div class="col-md-3">
                <div class="form-group">
                  <label>&nbsp;</label>
                  <button class="btn btn-outline-dark btn-fw form-control">Фильтр</button>
                </div>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-md-12 grid-margin">
      <?php if(session('error')): ?>
        <div class="alert alert-warning"><?php echo e(session('error')); ?></div>
      <?php endif; ?>
      <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
      <?php endif; ?>
      <div class="card">
        <div class="card-body table">
          <div class="table-responsive">
            <table class="table">
              <thead>
                <th width="36px"><input type="checkbox" class="select_all" /></th>
                <th width="36px">ID</th>
                <th>Категория</th>
                <th>Название</th>
                <th>Фильтр</th>
                <th width="200px" align="right">Действия</th>
              </thead>
              <tbody>
                <?php if($list->count()): ?>
                  <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><input type="checkbox" name="ids[]" value="<?php echo e($rec->id); ?>" /></td>
                      <td><?php echo e($rec->id); ?></td>
                      <td><?php echo e($rec->category->name); ?></td>
                      <td><?php echo e($rec->name); ?></td>
                      <td>
                        <?php if($rec->is_filter): ?>
                          <span class="badge badge-success">Используется</span>
                        <?php else: ?>
                          <span class="badge badge-danger">Не используется</span>
                        <?php endif; ?>
                      </td>
                      <td align="right">
                        <a href="<?php echo e(route('admin_task_type_form', $rec->id)); ?>" class="badge badge-info">
                          <i class="remove mdi mdi-pencil"></i></a>
                        <a href="<?php echo e(route('admin_delete_record', ['task_type', $rec->id])); ?>" data-confirm="Удалить тип задач <?php echo e($rec->name); ?>?" class="confirm badge badge-danger">
                          <i class="remove mdi mdi-close-circle-outline"></i></a>
                      </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                  <tr>
                    <td colspan="4">Нет информации</td>
                  </tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/i/indesiv4/indesiv4.beget.tech/public_html/resources/views/admin/category_tags/task_type_list.blade.php ENDPATH**/ ?>