<?php $__env->startSection('content'); ?>
  <div class="page-header">
    <h3 class="page-title">
			<span class="page-title-icon bg-gradient-primary text-white me-2">
				<i class="mdi mdi-flag"></i>
			</span>
      <?php echo e($page_title); ?>

    </h3>
    <a href="<?php echo e(route('admin.mentor_services.index')); ?>" class="btn btn-dark">Вернуться к списку</a>
  </div>
  <div class="row">
    <div class="col-md-12 grid-margin">
      <?php echo $__env->make('layouts.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div class="card">
        <div class="card-body">
          <form action="<?php echo e(route('admin.mentor_services.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
              <label>Услуга: *</label>
              <select name="type_service" class="select2 form-control-sm form-control">
                <option value="">Выберите</option>
                <?php if(count($service_types)): ?>
                  <?php $__currentLoopData = $service_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($index); ?>" <?php if($index == old('type_service', '')): ?> selected <?php endif; ?>>
                      <?php if($item == 'main'): ?>
                        Основная
                      <?php else: ?>
                        Дополнительная
                      <?php endif; ?>
                    </option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
              </select>
            </div>
            <div class="form-group">
              <label>Название: *</label>
              <input type="text" name="name" value="<?php echo e(old('name', '')); ?>" placeholder="Например: Иванов" class="form-control-sm form-control" />
            </div>
            
            
            <div class="form-group">
              <button class="btn btn-primary" type="submit" name="return" value="1">Сохранить и выйти</button>
              <button class="btn btn-success" type="submit">Сохранить</button>
              <a href="<?php echo e(route('admin.mentor_services.index')); ?>" class="btn btn-danger">Выйти без сохранения</a>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/i/indesiv4/indesiv4.beget.tech/public_html/resources/views/admin/mentor_services/add.blade.php ENDPATH**/ ?>