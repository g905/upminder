<?php $__env->startSection('content'); ?>
	<div class="page-header">
		<h3 class="page-title">
			<span class="page-title-icon bg-gradient-primary text-white me-2">
				<i class="mdi mdi-flag"></i>
			</span> 
			<?php echo e($page_title); ?>

		</h3>
		<a href="<?php echo e(route('admin_company_list')); ?>" class="btn btn-dark">Вернуться к списку</a>
	</div>
			<?php $__errorArgs = ['categories'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				<div class="alert alert-warning"><?php echo e($message); ?></div>
			<?php endif; ?>
			<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				<div class="alert alert-warning"><?php echo e($message); ?></div>
			<?php endif; ?>
			<?php $__errorArgs = ['law_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				<div class="alert alert-warning"><?php echo e($message); ?></div>
			<?php endif; ?>
			<?php $__errorArgs = ['inn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				<div class="alert alert-warning"><?php echo e($message); ?></div>
			<?php endif; ?>
			<?php $__errorArgs = ['contact_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				<div class="alert alert-warning"><?php echo e($message); ?></div>
			<?php endif; ?>
			<?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				<div class="alert alert-warning"><?php echo e($message); ?></div>
			<?php endif; ?>
			<?php if(session('success')): ?>
				<div class="alert alert-success"><?php echo e(session('success')); ?></div>
			<?php endif; ?>
	<div class="btn-group">
		<button type="button" data-card="general" class="btn btn-small btn-primary btn-tabs show_card active">Общая информация</button>
		<button type="button" data-card="contacts" class="btn btn-small btn-primary btn-tabs show_card">Контакты</button>
		<button type="button" data-card="cv" class="btn btn-small btn-primary btn-tabs show_card">Описание</button>
	</div>
	<div class="row">
		<div class="col-md-12 grid-margin">
			<form action="<?php echo e(route('admin_company_form', $id)); ?>" method="POST" class="form_group_margin company_form">
				<input id="ajax_url" type="hidden" value="<?php echo e(route('admin_company_ajax')); ?>" />
				<input id="show_tab" type="hidden" value="<?php echo e($show_tab); ?>" />
				<?php echo csrf_field(); ?>
				<div class="card">
					<div class="card-body dynamic general">						
						<div class="form-group">
							<label>Категории: *</label>
							<select name="categories[]" size="7" multiple class="select2 multiple form-control-sm form-control">
								<?php if($list_categories->count()): ?>
									<?php $__currentLoopData = $list_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rec_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($rec_list->id); ?>" <?php if(in_array($rec_list->id, $cat_list)): ?> selected <?php endif; ?> <?php if($rec_list->id == old('parent_id', $rec->parent_id)): ?> selected <?php endif; ?>><?php echo e($rec_list->name); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php endif; ?>
							</select>
						</div>
						<div class="form-group">
							<label>Страна:</label>
							<select name="country_id" class="select2 load_cities form-control-sm form-control">
								<option value="">Не указана</option>
								<?php if($list_countries->count()): ?>
									<?php $__currentLoopData = $list_countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rec_country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($rec_country->id); ?>" <?php if($rec_country->id == old('country_id', $rec->country_id)): ?> selected <?php endif; ?>><?php echo e($rec_country->name); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php endif; ?>
							</select>
						</div>
						<div class="form-group">
							<label>Город:</label>
							<?php if(!$id): ?>
								<select name="city_id" disabled class="form-control-sm form-control">
									<option value="">Выберите сначала страну</option>
								</select>
							<?php else: ?>
								<select name="city_id" class="form-control-sm form-control">
									<option value="">Выберите сначала страну</option>
									<?php if($list_cities->count()): ?>
										<?php $__currentLoopData = $list_cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rec_city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($rec_city->id); ?>" <?php if($rec_city->id == old('city_id', $rec->city_id)): ?> selected <?php endif; ?>><?php echo e($rec_city->name); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
								</select>								
							<?php endif; ?>
						</div>
						<div class="form-group">
							<label>Название: *</label>
							<input type="text" name="name" value="<?php echo e(old('name', $rec->name)); ?>" placeholder="Например: Строительная компания Раз" class="form-control-sm form-control" />
						</div>
						<div class="form-group">
							<label>Юридическое название: *</label>
							<input type="text" name="law_name" value="<?php echo e(old('law_name', $rec->law_name)); ?>" placeholder="" class="form-control-sm form-control" />
						</div>
						<div class="form-group">
							<label>ИНН: *</label>
							<input type="text" name="inn" value="<?php echo e(old('inn', $rec->inn)); ?>" class="form-control-sm form-control" />
						</div>
					</div>
					<div class="card-body dynamic contacts">
						<div class="form-group">
							<label>Контактное лицо:</label>
							<input type="text" name="contact_name" value="<?php echo e(old('contact_name', $rec->contact_name)); ?>" class="form-control" />
						</div>					
						<div class="form-group">
							<label>E-mail:</label>
							<input type="email" name="email" value="<?php echo e(old('email', $rec->email)); ?>" class="form-control" />
						</div>
						<div class="form-group">
							<label>Телефон:</label>
							<input type="phone" name="phone" value="<?php echo e(old('phone', $rec->phone)); ?>" class="form-control" />
						</div>	
						<div class="form-group">
							<label>URL сайта:</label>
							<input type="text" name="website" value="<?php echo e(old('website', $rec->website)); ?>" class="form-control" />
						</div>							
					</div>					
					<div class="card-body dynamic cv">	
						<div class="form-group">
							<label>Описание *:</label>
							<textarea name="description" rows="10" class="form-control"><?php echo e(old('description', $rec->description)); ?></textarea>
						</div>					
					</div>
				</div>
				<br /><br /> 
				<div class="form-group">
					<input id="redirect" type="hidden" name="redirect" value="true" />
					<button class="btn btn-success">Сохранить и выйти</button>
					<button type="button" name="apply" onclick="document.getElementById('redirect').value = 'false'; form.submit();" class="btn btn-info">Применить</button>
					<a href="{[ route('admin_company_list') }}" class="btn btn-warning">Выйти без сохранения</a>
				</div>
			</form>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/i/indesiv4/indesiv4.beget.tech/public_html/resources/views/admin/company_form.blade.php ENDPATH**/ ?>