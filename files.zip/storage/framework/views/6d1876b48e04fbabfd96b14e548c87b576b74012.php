

<?php $__env->startSection('content'); ?>
	<div class="page-header">
		<h3 class="page-title">
			<span class="page-title-icon bg-gradient-primary text-white me-2">
				<i class="mdi mdi-flag"></i>
			</span> 
			<?php echo e($page_title); ?>

		</h3>
		<a href="<?php echo e(route('admin_country_form', 0)); ?>" class="btn btn-success">Добавить</a>
	</div>
	<div class="row">
		<div class="col-md-12 grid-margin">
			<?php if(session('error')): ?>
				<div class="alert alert-warning"><?php echo e(session('error')); ?></div>
			<?php endif; ?>
			<?php if(session('success')): ?>
				<div class="alert alert-success"><?php echo e(session('success')); ?></div>
			<?php endif; ?>
			<div class="card">
				<div class="card-body table">
					<div class="table-responsive">
						<table class="table">
							<thead>
								<th width="36px"><input type="checkbox" class="select_all" /></th>
								<th width="36px">ID</th>
								<th>Название</th>
								<th width="200px" align="right">Действия</th>
							</thead>
							<tbody>
								<?php if($list->count()): ?>
									<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<tr>
											<td><input type="checkbox" name="ids[]" value="<?php echo e($rec->id); ?>" /></td>
											<td><?php echo e($rec->id); ?></td>
											<td><?php echo e($rec->name); ?></td>
											<td align="right">
												<a href="<?php echo e(route('admin_country_form', $rec->id)); ?>" class="badge badge-info"><i class="remove mdi mdi-pencil"></i></a>
												<a href="<?php echo e(route('admin_delete_record', ['country', $rec->id])); ?>" data-confirm="Удалить страну <?php echo e($rec->name); ?>?" class="confirm badge badge-danger"><i class="remove mdi mdi-close-circle-outline"></i></a>
											</td>
										</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php else: ?>
									<tr>
										<td colspan="3">Нет информации</td>
									</tr>
								<?php endif; ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\indesiv4.loc\resources\views/admin/country_list.blade.php ENDPATH**/ ?>