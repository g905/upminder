

<?php $__env->startSection('content'); ?>
	<div class="page-header">
		<h3 class="page-title">
			<span class="page-title-icon bg-gradient-primary text-white me-2">
				<i class="mdi mdi-home"></i>
			</span> 
			<?php echo e($page_title); ?>

		</h3>
		<a href="<?php echo e(route('admin_page_form', 0)); ?>" class="btn btn-success">Добавить</a>
	</div>
	<div class="row">
		<div class="col-md-12 grid-margin">
			<?php if(session('error')): ?>
				<div class="alert alert-warning"><?php echo e(session('error')); ?></div>
			<?php endif; ?>
			<?php if(session('success')): ?>
				<div class="alert alert-success"><?php echo e(session('success')); ?></div>
			<?php endif; ?>
			<div class="card">
				<div class="card-body table">
					<div class="table-responsive">
						<table class="table">
							<thead>
								<th width="36px"><input type="checkbox" class="select_all" /></th>
								<th width="36px">
									ID
									<?php if($order_by == 'id'): ?>
										<?php if($order_by_asc == 'desc'): ?>
											<a href="<?php echo e(route('admin_page_list', 'order_by=id&order_by_asc=asc')); ?>">&LeftDownVectorBar;</a>
										<?php else: ?>
											<a href="<?php echo e(route('admin_page_list', 'order_by=id&order_by_asc=desc')); ?>">&LeftUpVectorBar;</a>
										<?php endif; ?>
									<?php else: ?>
										<a href="<?php echo e(route('admin_page_list', 'order_by=id&order_by_asc=desc')); ?>">&LeftUpVectorBar;</a>
									<?php endif; ?>
								</th>
								<th width="250px">
									Заголовок
									<?php if($order_by == 'title'): ?>
										<?php if($order_by_asc == 'desc'): ?>
											<a href="<?php echo e(route('admin_page_list', 'order_by=title&order_by_asc=asc')); ?>">&LeftDownVectorBar;</a>
										<?php else: ?>
											<a href="<?php echo e(route('admin_page_list', 'order_by=title&order_by_asc=desc')); ?>">&LeftUpVectorBar;</a>
										<?php endif; ?>
									<?php else: ?>
										<a href="<?php echo e(route('admin_page_list', 'order_by=title&order_by_asc=desc')); ?>">&LeftUpVectorBar;</a>
									<?php endif; ?>	
								</th>
								<th width="250px">URL</th>
								<th align="center">Доступна</th>
								<th width="200px" align="right">Действия</th>
							</thead>
							<tbody>
								<?php if($list->count()): ?>
									<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								
										<tr>
										
											<td><input type="checkbox" name="ids[]" value="<?php echo e($rec->id); ?>" /></td>
											<td><?php echo e($rec->id); ?></td>
											<td><a href="<?php echo e(route('admin_page_form', $rec->id)); ?>"><?php echo e($rec->title); ?></a></td>
											<td><a href="/<?php echo e($rec->slug); ?>"><?php echo e($rec->slug); ?></a></td>
											<td>
												<?php if($rec->active): ?>
													<span class="badge badge-success">Доступна</span>
												<?php else: ?>
													<span class="badge badge-warning">Недоступна</span>
												<?php endif; ?>											
											</td>
											<td align="right">
												<a href="<?php echo e(route('admin_page_form', $rec->id)); ?>" class="badge badge-info"><i class="remove mdi mdi-pencil"></i></a>
												<a href="<?php echo e(route('admin_delete_record', ['page', $rec->id])); ?>" data-confirm="Удалить страницу <?php echo e($rec->title); ?>?" class="confirm badge badge-danger"><i class="remove mdi mdi-close-circle-outline"></i></a>
											</td>
											
										</tr>
								
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php else: ?>
									<tr>
										<td colspan="15">Нет информации</td>
									</tr>
								<?php endif; ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\indesiv4.loc\resources\views/admin/page_list.blade.php ENDPATH**/ ?>