

<?php $__env->startSection('content'); ?>
	<div class="page-header">
		<h3 class="page-title">
			<span class="page-title-icon bg-gradient-primary text-white me-2">
				<i class="mdi mdi-flag"></i>
			</span> 
			<?php echo e($page_title); ?>

		</h3>
		<a href="<?php echo e(route('admin_mentor_list')); ?>" class="btn btn-dark">Вернуться к списку</a>
	</div>
			<?php $__errorArgs = ['categories'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				<div class="alert alert-warning"><?php echo e($message); ?></div>
			<?php endif; ?>
			<?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				<div class="alert alert-warning"><?php echo e($message); ?></div>
			<?php endif; ?>
			<?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				<div class="alert alert-warning"><?php echo e($message); ?></div>
			<?php endif; ?>
			<?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				<div class="alert alert-warning"><?php echo e($message); ?></div>
			<?php endif; ?>
			<?php $__errorArgs = ['help_text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				<div class="alert alert-warning"><?php echo e($message); ?></div>
			<?php endif; ?>
			<?php if(session('success')): ?>
				<div class="alert alert-success"><?php echo e(session('success')); ?></div>
			<?php endif; ?>
	<div class="btn-group">
		<button type="button" data-card="general" class="btn btn-small btn-primary btn-tabs show_card active">Общая информация</button>
		<button type="button" data-card="contacts" class="btn btn-small btn-primary btn-tabs show_card">Контакты</button>
		<button type="button" data-card="cv" class="btn btn-small btn-primary btn-tabs show_card">Описание и задачи</button>
		<button type="button" data-card="experience" class="btn btn-small btn-primary btn-tabs show_card">Опыт работы</button>
		<button type="button" data-card="education" class="btn btn-small btn-primary btn-tabs show_card">Образование и языки</button>
		<button type="button" data-card="services" class="btn btn-small btn-primary btn-tabs show_card">Услуги</button>
	</div>
	<div class="row">
		<div class="col-md-12 grid-margin">
			<form action="<?php echo e(route('admin_mentor_form', $id)); ?>" method="POST" class="form_group_margin mentor_form">
				<input id="ajax_url" type="hidden" value="<?php echo e(route('admin_mentor_ajax')); ?>" />
				<input id="show_tab" type="hidden" value="<?php echo e($show_tab); ?>" />
				<?php echo csrf_field(); ?>
				<div class="card">
					<div class="card-body dynamic general">						
						<div class="form-group">
							<label>Категории: *</label>
							<select name="categories[]" size="7" multiple class="select2 multiple form-control-sm form-control">
								<?php if($list_categories->count()): ?>
									<?php $__currentLoopData = $list_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rec_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($rec_list->id); ?>" <?php if(in_array($rec_list->id, $cat_list)): ?> selected <?php endif; ?> <?php if($rec_list->id == old('parent_id', $rec->parent_id)): ?> selected <?php endif; ?>><?php echo e($rec_list->name); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php endif; ?>
							</select>
						</div>
						<div class="form-group">
							<label>Страна:</label>
							<select name="country_id" class="select2 load_cities form-control-sm form-control">
								<option value="">Не указан</option>
								<?php if($list_countries->count()): ?>
									<?php $__currentLoopData = $list_countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rec_country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($rec_country->id); ?>" <?php if($rec_country->id == old('country_id', $rec->country_id)): ?> selected <?php endif; ?>><?php echo e($rec_country->name); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php endif; ?>
							</select>
						</div>
						<div class="form-group">
							<label>Город:</label>
							<?php if(!$id): ?>
								<select name="city_id" disabled class="form-control-sm form-control">
									<option value="">Выберите сначала страну</option>
								</select>
							<?php else: ?>
								<select name="city_id" class="form-control-sm form-control">
									<option value="">Выберите сначала страну</option>
									<?php if($list_cities->count()): ?>
										<?php $__currentLoopData = $list_cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rec_city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($rec_city->id); ?>" <?php if($rec_city->id == old('city_id', $rec->city_id)): ?> selected <?php endif; ?>><?php echo e($rec_city->name); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
								</select>								
							<?php endif; ?>
						</div>
						<div class="form-group">
							<label>Фамилия: *</label>
							<input type="text" name="last_name" value="<?php echo e(old('last_name', $rec->last_name)); ?>" placeholder="Например: Иванов" class="form-control-sm form-control" />
						</div>
						<div class="form-group">
							<label>Имя: *</label>
							<input type="text" name="first_name" value="<?php echo e(old('first_name', $rec->first_name)); ?>" placeholder="Например: Иван" class="form-control-sm form-control" />
						</div>
						<div class="form-group">
							<label>Отчество:</label>
							<input type="text" name="surname" value="<?php echo e(old('surname', $rec->surname)); ?>" placeholder="Например: Петрович" class="form-control-sm form-control" />
						</div>
						<div class="form-group">
							<label>Профиль верифицирован?</label>
							<div class="form-check">
								<label class="form-check-label">
									<input <?php if(old('verified', $rec->verified) == 1): ?> checked <?php endif; ?> id="verified1" type="radio" name="verified" value="1" class="form-check-input" />
									Да, верифицирован
									<i class="input-helper"></i>
								</label>
							</div>
							<div class="form-check">
								<label class="form-check-label">
									<input <?php if(old('verified', $rec->verified) == 0): ?> checked <?php endif; ?> id="verified0" type="radio" name="verified" value="0" class="form-check-input" />
									Нет, не верифицирован
									<i class="input-helper"></i>
								</label>
							</div>
						</div>
						<br />
						<div class="form-group">
							<label>VIP аккаунт?</label>
							<div class="form-check">
								<label class="form-check-label">
									<input <?php if(old('vip_status', $rec->vip_status) == 1): ?> checked <?php endif; ?> id="vip_status1" type="radio" name="vip_status" value="1" class="form-check-input" />
									Да, аккаунт VIP
									<i class="input-helper"></i>
								</label>
							</div>
							<div class="form-check">
								<label class="form-check-label">
									<input <?php if(old('vip_status', $rec->vip_status) == 0): ?> checked <?php endif; ?> id="vip_status0" type="radio" name="vip_status" value="0" class="form-check-input" />
									Нет, обычный аккаунт
									<i class="input-helper"></i>
								</label>
							</div>
						</div>
					</div>
					<div class="card-body dynamic contacts">	
						<div class="form-group">
							<label>E-mail:</label>
							<input type="email" name="email" value="<?php echo e(old('email', $rec->email)); ?>" class="form-control" />
						</div>
						<div class="form-group">
							<label>Телефон:</label>
							<input type="phone" name="phone" value="<?php echo e(old('phone', $rec->phone)); ?>" class="form-control" />
						</div>	
						<div class="form-group">
							<label>Telegram:</label>
							<input type="text" name="telegram" value="<?php echo e(old('telegram', $rec->telegram)); ?>" class="form-control" />
						</div>							
					</div>					
					<div class="card-body dynamic cv">	
						<div class="form-group">
							<label>Описание *:</label>
							<textarea name="description" rows="10" class="form-control"><?php echo e(old('description', $rec->description)); ?></textarea>
						</div>
						<div class="form-group">
							<label>Чем могу помочь *:</label>
							<textarea name="help_text" rows="10" class="form-control"><?php echo e(old('help_text', $rec->help_text)); ?></textarea>
						</div>					
					</div>
					<div class="card-body dynamic education">
						<a href="javascript:void(0);" data-tpl="education_tpl" data-row="row_education" class="add_row btn btn-warning">Добавить ещё</a>
						<br /><br />
						<div id="education_tpl" class="row row_education0 row_education row_tpl">
							<div class="col-md-3">
								<div class="form-group">
									<label>Дата начала: *</label>  
									<input type="date" name="education_date_start[]" value="" class="form-control" />
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label>Дата окончания: *</label>
									<input type="date" name="education_date_end[]" value="" class="form-control" />
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label>Учебное заведение: *</label>
									<input type="text" name="education_school[]" value="" class="form-control" />
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label>Название курса: *</label>
									<input type="text" name="education_course[]" value="" class="form-control minus_button" />
									<a href="javascript:void(0);" data-row="row_education0" class="badge badge-danger delete_row btn_row"><i class="remove mdi mdi-close-circle-outline"></i></a>
								</div>
							</div>
						</div>
						<?php if($id > 0): ?>
							<?php if($edu_list->count()): ?>
								<?php $__currentLoopData = $edu_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kk => $edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<div class="row row_education<?php echo e($kk + 1); ?> row_education">
										<div class="col-md-3">
											<div class="form-group">
												<label>Дата начала: *</label>  
												<input type="date" name="education_date_start[]" value="<?php echo e($edu->date_start); ?>" class="form-control" />
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<label>Дата окончания: *</label>
												<input type="date" name="education_date_end[]" value="<?php echo e($edu->date_end); ?>" class="form-control" />
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<label>Учебное заведение: *</label>
												<input type="text" name="education_school[]" value="<?php echo e($edu->school); ?>" class="form-control" />
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<label>Название курса: *</label>
												<input type="text" name="education_course[]" value="<?php echo e($edu->course); ?>" class="form-control minus_button" />
												<a href="javascript:void(0);" data-row="row_education<?php echo e($kk + 1); ?>" class="badge badge-danger delete_row btn_row"><i class="remove mdi mdi-close-circle-outline"></i></a>
											</div>
										</div>
									</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php endif; ?>
						<?php endif; ?>
						<div class="form-group">
							<label>Знание языков: *</label>
							<?php if($list_languages->count()): ?>
								<?php $__currentLoopData = $list_languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rec_lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<div class="form-check">
										<label class="form-check-label">
											<input type="checkbox" <?php if(in_array($rec_lang->id, $lang_list)): ?> checked <?php endif; ?> name="languages[]" value="<?php echo e($rec_lang->id); ?>" class="form-check-input" />
											<?php echo e($rec_lang->name); ?>

											<i class="input-helper"></i>
										</label>
									</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php endif; ?>
						</div>
					</div>
					<div class="card-body dynamic experience">
						<a href="javascript:void(0);" data-tpl="experience_tpl" data-row="row_experience" class="add_row btn btn-warning">Добавить ещё</a>
						<br /><br />
						<div id="experience_tpl" class="row row_experience0 row_experience row_tpl">
							<div class="col-md-3">
								<div class="form-group">
									<label>Дата начала: *</label>  
									<input type="date" name="experience_date_start[]" value="" class="form-control" />
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label>Дата окончания: *</label>
									<input type="date" name="experience_date_end[]" value="" class="form-control" />
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label>Компания: *</label>
									<input type="text" name="experience_company[]" value="" class="form-control" />
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label>Должность: *</label>
									<input type="text" name="experience_position[]" value="" class="form-control minus_button" />
									<a href="javascript:void(0);" data-row="row_experience0" class="badge badge-danger delete_row btn_row"><i class="remove mdi mdi-close-circle-outline"></i></a>
								</div>
							</div>
						</div>
						<?php if($id > 0): ?>
							<?php if($exp_list->count()): ?>
								<?php $__currentLoopData = $exp_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kk => $exp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<div class="row row_experience<?php echo e($kk + 1); ?> row_experience">
										<div class="col-md-3">
											<div class="form-group">
												<label>Дата начала: *</label>  
												<input type="date" name="experience_date_start[]" value="<?php echo e($exp->date_start); ?>" class="form-control" />
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<label>Дата окончания: *</label>
												<input type="date" name="experience_date_end[]" value="<?php echo e($exp->date_end); ?>" class="form-control" />
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<label>Компания: *</label>
												<input type="text" name="experience_company[]" value="<?php echo e($exp->company); ?>" class="form-control" />
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<label>Должность: *</label>
												<input type="text" name="experience_position[]" value="<?php echo e($exp->position); ?>" class="form-control minus_button" />
												<a href="javascript:void(0);" data-row="row_experience<?php echo e($kk + 1); ?>" class="badge badge-danger delete_row btn_row"><i class="remove mdi mdi-close-circle-outline"></i></a>
											</div>
										</div>
									</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php endif; ?>
						<?php endif; ?>
						<div class="form-group">
							<label>Опыт в профессии:</label>  
							<input type="text" name="experience" value="<?php echo e(old('experience', $rec->experience)); ?>" class="form-control" />
						</div>
					</div>
					<div class="card-body dynamic services">
						<a href="javascript:void(0);" data-tpl="service_tpl" data-row="row_service" class="add_row btn btn-warning">Добавить ещё</a>
						<br /><br />
						<div id="service_tpl" class="row row_service0 row_service row_tpl">
							<div class="col-md-3">
								<div class="form-group">
									<label>Название услуги: *</label>  
									<input type="text" name="service_service[]" value="" class="form-control" />
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label>Валюта: *</label>
									<select name="service_currency_id[]" class="form-control-sm form-control">
										<?php if($list_currencies->count()): ?>
											<?php $__currentLoopData = $list_currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rec_curr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($rec_curr->id); ?>"><?php echo e($rec_curr->name); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										<?php endif; ?>
									</select>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label>Цена в выбранной валюте: *</label>
									<input type="text" name="service_price[]" value="" class="form-control" />
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label>Скидка в %: *</label>
									<input type="text" name="service_discount[]" value="" class="form-control" />
									<a href="javascript:void(0);" data-row="row_service0" class="badge badge-danger delete_row btn_row"><i class="remove mdi mdi-close-circle-outline"></i></a>
								</div>
							</div>
						</div>
						<?php if($id > 0): ?>
							<?php if($services_list->count()): ?>
								<?php $__currentLoopData = $services_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kk => $serv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<div class="row row_service<?php echo e($kk + 1); ?> row_service">
										<div class="col-md-3">
											<div class="form-group">
												<label>Название услуги: *</label>  
												<input type="text" name="service_service[]" value="<?php echo e($serv->service); ?>" class="form-control" />
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<label>Валюта: *</label>
												<select name="service_currency_id[]" class="form-control-sm form-control">
													<?php if($list_currencies->count()): ?>
														<?php $__currentLoopData = $list_currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rec_curr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
															<option value="<?php echo e($rec_curr->id); ?>" <?php if($serv->currency_id == $rec_curr->id): ?> selected <?php endif; ?>><?php echo e($rec_curr->name); ?></option>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													<?php endif; ?>
												</select>
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<label>Цена в выбранной валюте: *</label>
												<input type="text" name="service_price[]" value="<?php echo e($serv->price); ?>" class="form-control" />
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<label>Скидка в %: *</label>
												<input type="text" name="service_discount[]" value="<?php echo e($serv->discount); ?>" class="form-control minus_button" />
												<a href="javascript:void(0);" data-row="row_service0" class="badge badge-danger delete_row btn_row"><i class="remove mdi mdi-close-circle-outline"></i></a>
											</div>
										</div>
									</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php endif; ?>
						<?php endif; ?>
					</div>
				</div>
				<br /><br />
				<div class="form-group">
					<input id="redirect" type="hidden" name="redirect" value="true" />
					<button class="btn btn-success">Сохранить и выйти</button>
					<button type="button" name="apply" onclick="document.getElementById('redirect').value = 'false'; form.submit();" class="btn btn-info">Применить</button>
					<a href="{[ route('admin_mentor_list') }}" class="btn btn-warning">Выйти без сохранения</a>
				</div>
			</form>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\indesiv4.loc\resources\views/admin/mentor_form.blade.php ENDPATH**/ ?>