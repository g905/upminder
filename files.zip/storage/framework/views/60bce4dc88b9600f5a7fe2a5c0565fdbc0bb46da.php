

<?php $__env->startSection('content'); ?>
	<div class="page-header">
		<h3 class="page-title">
			<span class="page-title-icon bg-gradient-primary text-white me-2">
				<i class="mdi mdi-flag"></i>
			</span> 
			<?php echo e($page_title); ?>

		</h3>
		<a href="<?php echo e(route('admin_rev_list')); ?>" class="btn btn-dark">Вернуться к списку</a>
	</div>
	<div class="row">
		<div class="col-md-12 grid-margin">
			<?php $__errorArgs = ['mentor_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				<div class="alert alert-warning"><?php echo e($message); ?></div>
			<?php endif; ?>
			<?php $__errorArgs = ['author'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				<div class="alert alert-warning"><?php echo e($author); ?></div>
			<?php endif; ?>
			<?php $__errorArgs = ['text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				<div class="alert alert-warning"><?php echo e($text); ?></div>
			<?php endif; ?>
			<?php if(session('success')): ?>
				<div class="alert alert-success"><?php echo e(session('success')); ?></div>
			<?php endif; ?>
			<div class="card">
				<div class="card-body">
					<form action="<?php echo e(route('admin_rev_form', $id)); ?>" method="POST">
						<?php echo csrf_field(); ?>
						<div class="form-group">
							<label>Для ментора: *</label>
							<select name="mentor_id" class="select2 form-control-sm form-control">
								<option value="">Выберите</option>
								<?php if($list->count()): ?>
									<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rec_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($rec_list->id); ?>" <?php if($rec_list->id == old('mentor_id', $rec->mentor_id)): ?> selected <?php endif; ?>><?php echo e($rec_list->last_name); ?> <?php echo e($rec_list->first_name); ?> <?php echo e($rec_list->surname); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php endif; ?>
							</select>
						</div>
						<div class="form-group">
							<label>Автор: *</label>
							<input type="text" name="author" value="<?php echo e(old('author', $rec->author)); ?>" placeholder="Например: Иван" class="form-control-sm form-control" />
						</div>
						<div class="form-group">
							<label>Текст отзыва: *</label>
							<textarea name="text" rows="8" class="visual form-control"><?php echo e(old('text', $rec->text)); ?></textarea>
						</div>
						<div class="form-group">
							<label>Тип отзыва:</label>
							<div class="form-check">
								<label class="form-check-label">
									<input <?php if(old('type', $rec->type) == 1): ?> checked <?php endif; ?> id="type1" type="radio" name="type" value="1" class="form-check-input" />
									Положительный
									<i class="input-helper"></i>
								</label>
							</div>
							<div class="form-check">
								<label class="form-check-label">
									<input <?php if(old('type', $rec->type) == 2): ?> checked <?php endif; ?> id="type0" type="radio" name="type" value="2" class="form-check-input" />
									Негативный
									<i class="input-helper"></i>
								</label>
							</div>
						</div>
						<div class="form-group">
							<label>Отображается на сайте?</label>
							<div class="form-check">
								<label class="form-check-label">
									<input <?php if(old('active', $rec->active) == 1): ?> checked <?php endif; ?> id="active1" type="radio" name="active" value="1" class="form-check-input" />
									Да, отображается
									<i class="input-helper"></i>
								</label>
							</div>
							<div class="form-check">
								<label class="form-check-label">
									<input <?php if(old('active', $rec->active) == 0): ?> checked <?php endif; ?> id="active0" type="radio" name="active" value="0" class="form-check-input" />
									Нет, не отображается
									<i class="input-helper"></i>
								</label>
							</div>
						</div>
						<div class="form-group">
							<button class="btn btn-success">Сохранить</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\indesiv4.loc\resources\views/admin/review_form.blade.php ENDPATH**/ ?>