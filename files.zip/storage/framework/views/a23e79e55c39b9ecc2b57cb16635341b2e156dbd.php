<form action="<?php echo e($filter_route); ?>">
  <div class="card-body dynamic filters <?php if(!request('mentor_id')): ?> filter_hide <?php else: ?> shown <?php endif; ?>">
    <div class="row">
      <div class="col-md-3">
        <div class="form-group">
          <label>Ментор:</label>
          <select name="mentor_id" class="select2 form-control-sm form-control">
            <option value="">Все менторы</option>
            <?php if($mentors->count()): ?>
              <?php $__currentLoopData = $mentors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mentor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($mentor->id); ?>"
                    <?php if(request('mentor_id') == $mentor->id): ?> selected="selected" <?php endif; ?>>
                  <?php echo e($mentor->last_name); ?> <?php echo e($mentor->first_name); ?> <?php echo e($mentor->surname); ?>

                </option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
          </select>
        </div>
      </div>
      <div class="col-md-3">
        <div class="form-group">
          <label>&nbsp;</label>
          <button class="btn btn-outline-dark btn-fw form-control">Применить</button>
        </div>
      </div>
    </div>
  </div>
</form><?php /**PATH /home/i/indesiv4/indesiv4.beget.tech/public_html/resources/views/admin/components/filter-by-mentor.blade.php ENDPATH**/ ?>