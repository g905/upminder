

<?php $__env->startSection('content'); ?>
  <div class="page-header">
    <h3 class="page-title">
			<span class="page-title-icon bg-gradient-primary text-white me-2">
				<i class="mdi mdi-flag"></i>
			</span>
      <?php echo e($page_title); ?>

    </h3>
    <a href="<?php echo e(route('admin.lessons.index')); ?>" class="btn btn-dark">Вернуться к списку</a>
  </div>
  <div class="row">
    <div class="col-md-12 grid-margin">
      <?php echo $__env->make('layouts.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div class="card">
        <div class="card-body">
          <form action="<?php echo e(route('admin.lessons.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
              <label>Для ментора: *</label>
              <select name="mentor_id" class="select2 form-control-sm form-control">
                <option value="">Выберите</option>
                <?php if($mentors->count()): ?>
                  <?php $__currentLoopData = $mentors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mentor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($mentor->id); ?>" <?php if($mentor->id == old('mentor_id', $mentor->mentor_id)): ?> selected <?php endif; ?>><?php echo e($mentor->last_name); ?> <?php echo e($mentor->first_name); ?> <?php echo e($mentor->surname); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
              </select>
            </div>
            <div class="form-group">
              <label>Клиент: *</label>
              <input type="text" name="client" value="<?php echo e(old('client' ?? '')); ?>" placeholder="Например: Иван" class="form-control-sm form-control" />
            </div>
            <div class="form-group">
              <label>Цена: *</label>
              <input type="text" name="price" value="<?php echo e(old('price' ?? '')); ?>" placeholder="" class="form-control-sm form-control" />
            </div>
            <div class="form-group">
              <label>Дата начала: *</label>
              <input type="date" name="date_start" value="" class="form-control" />
            </div>
            <div class="form-group">
              <label>Время начала: *</label>
              <input type="time" name="time_start" value="" class="form-control" />
            </div>
            <div class="form-group">
              <label>Дата конца: *</label>
              <input type="date" name="date_end" value="" class="form-control" />
            </div>
            <div class="form-group">
              <label>Время конца: *</label>
              <input type="time" name="time_end" value="" class="form-control" />
            </div>
            <div class="form-group">
              <label>Описание: *</label>
              <textarea name="description" rows="8" class="visual form-control"><?php echo e(old('description') ?? ''); ?></textarea>
            </div>
            <div class="form-group">
              <button class="btn btn-success">Сохранить</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\indesiv4.loc\resources\views/admin/lessons/add.blade.php ENDPATH**/ ?>