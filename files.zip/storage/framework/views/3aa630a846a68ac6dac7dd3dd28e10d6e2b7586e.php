

<?php $__env->startSection('content'); ?>
	<div class="page-header">
		<h3 class="page-title">
			<span class="page-title-icon bg-gradient-primary text-white me-2">
				<i class="mdi mdi-home"></i>
			</span> 
			<?php echo e($page_title); ?>

		</h3>
		<a href="<?php echo e(route('admin_city_form', 0)); ?>" class="btn btn-success">Добавить</a>
	</div>
	<div class="btn-group">
		<button type="button" data-card="filters" class="btn btn-small btn-primary btn-tabs show_card <?php if($filters['applied']): ?> active <?php endif; ?>">Фильтрация</button>
		<button type="button" data-card="search" class="btn btn-small btn-primary btn-tabs show_card <?php if(!empty($filters['keyword'])): ?> active <?php endif; ?>">Поиск по городам</button>
	</div>
	<div class="row">
		<div class="col-md-12 grid-margin">
			<div class="card">
				<form action="<?php echo e(route('admin_city_list')); ?>">
				<div class="card-body dynamic filters <?php if(!$filters['applied']): ?> filter_hide <?php else: ?> shown <?php endif; ?>">
					<div class="row">
						<div class="col-md-3">
							<div class="form-group">
								<label>Страна:</label>
								<select name="filters[country_id]" class="select2 form-control-sm form-control">
									<option value="">Все страны</option>
									<?php if($countries->count()): ?>
										<?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($country->id); ?>" <?php if($filters['country_id'] == $country->id): ?> selected <?php endif; ?>><?php echo e($country->name); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
								</select>
							</div>
						</div>
						<div class="col-md-3">
							<div class="form-group">
								<label>&nbsp;</label>
								<button class="btn btn-outline-dark btn-fw form-control">Фильтр</button>
							</div>
						</div>
					</div>
				</div>
				</form>
				<form action="<?php echo e(route('admin_city_list')); ?>">
				<div class="card-body dynamic search <?php if(empty($filters['keyword'])): ?> filter_hide <?php else: ?> shown <?php endif; ?>">
					<div class="row">
						<div class="col-md-3">
							<div class="form-group">
								<label>Город:</label>
								<input type="text" name="keyword" value="<?php echo e($filters['keyword']); ?>" class="form-control" />
							</div>
						</div>
						<div class="col-md-3">
							<div class="form-group">
								<label>&nbsp;</label>
								<button class="btn btn-outline-dark btn-fw form-control">Поиск</button>
							</div>
						</div>
					</div>
				</div>
				</form>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-md-12 grid-margin">
			<?php if(session('error')): ?>
				<div class="alert alert-warning"><?php echo e(session('error')); ?></div>
			<?php endif; ?>
			<?php if(session('success')): ?>
				<div class="alert alert-success"><?php echo e(session('success')); ?></div>
			<?php endif; ?>
			<div class="card">
				<div class="card-body table">
					<div class="table-responsive">
						<table class="table">
							<thead>
								<th width="36px"><input type="checkbox" class="select_all" /></th>
								<th width="36px">ID</th>
								<th width="250px">Страна</th>
								<th>Название</th>
								<th width="200px" align="right">Действия</th>
							</thead>
							<tbody>
								<?php if($list->count()): ?>
									<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<tr>
											<td><input type="checkbox" name="ids[]" value="<?php echo e($rec->id); ?>" /></td>
											<td><?php echo e($rec->id); ?></td>
											<td><?php echo $rec->country; ?></td>
											<td><?php echo e($rec->name); ?></td>
											<td align="right">
												<a href="<?php echo e(route('admin_city_form', $rec->id)); ?>" class="badge badge-info"><i class="remove mdi mdi-pencil"></i></a>
												<a href="<?php echo e(route('admin_delete_record', ['city', $rec->id])); ?>" data-confirm="Удалить город <?php echo e($rec->name); ?>?" class="confirm badge badge-danger"><i class="remove mdi mdi-close-circle-outline"></i></a>
											</td>
										</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php else: ?>
									<tr>
										<td colspan="4">Нет информации</td>
									</tr>
								<?php endif; ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\indesiv4.loc\resources\views/admin/city_list.blade.php ENDPATH**/ ?>