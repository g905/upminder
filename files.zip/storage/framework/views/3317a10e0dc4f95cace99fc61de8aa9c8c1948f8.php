<?php $__env->startSection('content'); ?>
  <div class="page-header">
    <h3 class="page-title">
			<span class="page-title-icon bg-gradient-primary text-white me-2">
				<i class="mdi mdi-flag"></i>
			</span>
      <?php echo e($page_title); ?>

    </h3>
    <a href="<?php echo e(route('admin_task_type_list')); ?>" class="btn btn-dark">Вернуться к списку</a>
  </div>
  <div class="row">
    <div class="col-md-12 grid-margin">
      <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="alert alert-warning"><?php echo e($message); ?></div>
      <?php endif; ?>
      <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="alert alert-warning"><?php echo e($message); ?></div>
      <?php endif; ?>
      <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
      <?php endif; ?>
      <div class="card">
        <div class="card-body">
          <form action="<?php echo e(route('admin_task_type_form', $id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
              <label>Категория: *</label>
              <select name="category_id" class="select2 form-control-sm form-control">
                <option value="">Выберите</option>
                <?php $__currentLoopData = $parent_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <optgroup label="<?php echo e($parent->name); ?>">
                    <?php $__currentLoopData = $parent->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rec_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($rec_list->id); ?>" <?php if($rec_list->id == old('category_id', $rec->category_id)): ?> selected <?php endif; ?>><?php echo e($rec_list->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </optgroup>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
            <div class="form-group">
              <label>Название: *</label>
              <input type="text" name="name" value="<?php echo e(old('name', $rec->name)); ?>" placeholder="Например: телеграм бот" class="form-control-sm form-control" />
            </div>
            <div class="form-group">
              <label>Фильтр: *</label>
              <div class="form-check">
                <label class="form-check-label">
                  <input id="verified0" type="radio" name="is_filter" value="0" class="form-check-input" <?php if(!$rec->is_filter): ?> checked <?php endif; ?>/>
                    Не используется
                  <i class="input-helper"></i>
                </label>
              </div>
              <div class="form-check">
                <label class="form-check-label">
                  <input id="verified1" type="radio" name="is_filter" value="1" class="form-check-input" <?php if($rec->is_filter): ?> checked <?php endif; ?>/>
                    Используется
                  <i class="input-helper"></i>
                </label>
              </div>
            </div>
            <div class="form-group">
              <button class="btn btn-success">Сохранить</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/i/indesiv4/indesiv4.beget.tech/public_html/resources/views/admin/category_tags/task_type_form.blade.php ENDPATH**/ ?>