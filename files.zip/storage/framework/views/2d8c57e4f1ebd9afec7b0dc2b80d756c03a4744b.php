<?php $__env->startSection('content'); ?>
  <div class="page-header">
    <h3 class="page-title">
			<span class="page-title-icon bg-gradient-primary text-white me-2">
				<i class="mdi mdi-home"></i>
			</span>
      <?php echo e($page_title); ?>

    </h3>
    <a href="<?php echo e(route('admin.mentor_week.add', 0)); ?>" class="btn btn-success">Добавить</a>
  </div>
  <div class="btn-group">
    <button type="button" data-card="filters" class="btn btn-small btn-primary btn-tabs show_card <?php if(request('mentor_id')): ?> active <?php endif; ?>">Фильтрация</button>
    
  </div>
  <div class="row">
    <div class="col-md-12 grid-margin">
      <div class="card">
        <?php echo $__env->make('admin.components.filter-by-mentor', ['filter_route' => route('admin.mentor_week.index')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-md-12 grid-margin">
      <?php echo $__env->make('layouts.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div class="card">
        <div class="card-body table">
          <div class="table-responsive">
            <table class="table">
              <thead>
                <th width="36px"><input type="checkbox" class="select_all" /></th>
                <th width="36px">ID</th>
                <th width="250px">Ментор</th>
                <th width="200px">Категория</th>
                <th width="250px">Дата начала</th>
                <th width="250px">Дата конца</th>
                <th width="250px">Статус</th>
                <th width="200px" align="right">Действия</th>
              </thead>
              <tbody>
                <?php if($mentor_week->count()): ?>
                  <?php $__currentLoopData = $mentor_week; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><input type="checkbox" name="ids[]" value="<?php echo e($item->id); ?>" /></td>
                      <td><?php echo e($item->id); ?></td>
                      <td><?php echo e($item->mentor->last_name); ?> <?php echo e($item->mentor->first_name); ?></td>
                      <td>
                        <div class="mb-2">
                          <span class="badge badge-dark"><?php echo e($item->category->parent->name); ?></span>
                        </div>
                        <?php echo e($item->category->name); ?>

                      </td>
                      <td>
                        <div class="mb-2"><?php echo e($item->date_start->format('d.m.Y')); ?></div>
                        <div><?php echo e($item->date_start->format('H:i:s')); ?></div>
                      </td>
                      <td>
                       <div class="mb-2"><?php echo e($item->date_end->format('d.m.Y')); ?></div>
                        <div><?php echo e($item->date_end->format('H:i:s')); ?></div>
                      </td>
                      <td>
                        <?php if($item->is_active): ?>
                          <span class="badge badge-success">Активный</span>
                        <?php else: ?>
                          <span class="badge badge-danger">Не активный</span>
                        <?php endif; ?>
                      </td>
                      
                      <td align="right">
                        <a href="<?php echo e(route('admin.mentor_week.edit', $item->id)); ?>" class="badge badge-info">
                          <i class="remove mdi mdi-pencil"></i></a>
                        <a href="<?php echo e(route('admin.mentor_week.delete', [$item->id])); ?>" data-confirm="Удалить занятие?" class="confirm badge badge-danger">
                          <i class="remove mdi mdi-close-circle-outline"></i></a>
                      </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                  <tr>
                    <td colspan="4">Нет информации</td>
                  </tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
  <?php echo e($mentor_week->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/i/indesiv4/indesiv4.beget.tech/public_html/resources/views/admin/mentor_week/index.blade.php ENDPATH**/ ?>