<?php $__env->startSection('content'); ?>
    <div class="container-scroller">
      <div class="container-fluid page-body-wrapper full-page-wrapper">
        <div class="content-wrapper d-flex align-items-center auth">
          <div class="row flex-grow">
            <div class="col-lg-4 mx-auto">
              <div class="auth-form-light text-left p-5">
                <h4>Панель администратора</h4>
                <h6 class="font-weight-light">Войдите в аккаунт, чтобы продолжить.</h6>
				<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
					<div class="alert alert-warning"><?php echo e($message); ?></div>
				<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
					<div class="alert alert-warning"><?php echo e($message); ?></div>
				<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <form action="<?php echo e(route('login')); ?>" method="POST" class="pt-3">
					<?php echo csrf_field(); ?>
                  <div class="form-group">
                    <input type="email" name="email" value="<?php echo e(old('email')); ?>" placeholder="E-mail" class="form-control form-control-lg">
                  </div>
                  <div class="form-group">
                    <input type="password" name="password" placeholder="Пароль" class="form-control form-control-lg">
                  </div>
                  <div class="mt-3 text-center">
                    <button class="btn btn-block btn-info btn-lg font-weight-medium auth-form-btn">Войти</button>
					<p></p>
                    <a href="/password/reset" class="btn btn-block btn-warning btn-lg font-weight-medium">Забыл пароль?</a>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/i/indesiv4/indesiv4.beget.tech/public_html/resources/views/auth/login.blade.php ENDPATH**/ ?>