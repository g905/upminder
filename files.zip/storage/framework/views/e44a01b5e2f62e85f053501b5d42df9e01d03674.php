

<?php $__env->startSection('content'); ?>
	<div class="page-header">
		<h3 class="page-title">
			<span class="page-title-icon bg-gradient-primary text-white me-2">
				<i class="mdi mdi-home"></i>
			</span> 
			<?php echo e($page_title); ?>

		</h3>
		<a href="<?php echo e(route('admin_mentor_form', 0)); ?>" class="btn btn-success">Добавить</a>
	</div>
	<div class="btn-group">
		<button type="button" data-card="filters" class="btn btn-small btn-primary btn-tabs show_card <?php if($filters['applied']): ?> active <?php endif; ?>">Фильтрация</button>
		<button type="button" data-card="search" class="btn btn-small btn-primary btn-tabs show_card <?php if(!empty($filters['keyword'])): ?> active <?php endif; ?>">Поиск</button>
	</div>
	<div class="row">
		<div class="col-md-12 grid-margin">
			<div class="card">
				<form action="<?php echo e(route('admin_mentor_list')); ?>">
				<div class="card-body dynamic filters <?php if(!$filters['applied']): ?> filter_hide <?php else: ?> shown <?php endif; ?>">
					<div class="row">
						<div class="col-md-3">
							<div class="form-group">
								<label>Страна:</label>
								<select name="filters[country_id]" class="select2 form-control-sm form-control">
									<option value="">Все страны</option>
									<?php if($countries->count()): ?>
										<?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($country->id); ?>" <?php if($filters['country_id'] == $country->id): ?> selected <?php endif; ?>><?php echo e($country->name); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
								</select>
								<br />
								<a href="<?php echo e(route('admin_mentor_list')); ?>">Сбросить фильтры</a>
							</div>
						</div>
						<div class="col-md-3">
							<div class="form-group">
								<label>Категория:</label>
								<select name="filters[category_id]" class="select2 form-control-sm form-control">
									<option value="">Все страны</option>
									<?php if($categories->count()): ?>
										<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($cat->id); ?>" <?php if($filters['category_id'] == $cat->id): ?> selected <?php endif; ?>><?php echo e($cat->name); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
								</select>
							</div>
						</div>
						<div class="col-md-3">
							<div class="form-group">
								<label>&nbsp;</label>
								<button class="btn btn-outline-dark btn-fw form-control">Фильтр</button>
							</div>
						</div>
					</div>
				</div>
				</form>
				<form action="<?php echo e(route('admin_mentor_list')); ?>">
				<div class="card-body dynamic search <?php if(empty($filters['keyword'])): ?> filter_hide <?php else: ?> shown <?php endif; ?>">
					<div class="row">
						<div class="col-md-3">
							<div class="form-group">
								<label>ФИО / Телефон / E-mail:</label>
								<input type="text" name="keyword" value="<?php echo e($filters['keyword']); ?>" class="form-control" />
							</div>
						</div>
						<div class="col-md-3">
							<div class="form-group">
								<label>&nbsp;</label>
								<button class="btn btn-outline-dark btn-fw form-control">Поиск</button>
							</div>
						</div>
					</div>
				</div>
				</form>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-md-12 grid-margin">
			<?php if(session('error')): ?>
				<div class="alert alert-warning"><?php echo e(session('error')); ?></div>
			<?php endif; ?>
			<?php if(session('success')): ?>
				<div class="alert alert-success"><?php echo e(session('success')); ?></div>
			<?php endif; ?>
			<div class="card">
				<div class="card-body table">
					<div class="table-responsive">
						<table class="table">
							<thead>
								<th width="36px"><input type="checkbox" class="select_all" /></th>
								<th width="36px">
									ID
									<?php if($order_by == 'id'): ?>
										<?php if($order_by_asc == 'desc'): ?>
											<a href="<?php echo e(route('admin_mentor_list', 'order_by=id&order_by_asc=asc')); ?>">&LeftDownVectorBar;</a>
										<?php else: ?>
											<a href="<?php echo e(route('admin_mentor_list', 'order_by=id&order_by_asc=desc')); ?>">&LeftUpVectorBar;</a>
										<?php endif; ?>
									<?php else: ?>
										<a href="<?php echo e(route('admin_mentor_list', 'order_by=id&order_by_asc=desc')); ?>">&LeftUpVectorBar;</a>
									<?php endif; ?>
								</th>
								<th width="250px">
									Ф.И.О
									<?php if($order_by == 'last_name'): ?>
										<?php if($order_by_asc == 'desc'): ?>
											<a href="<?php echo e(route('admin_mentor_list', 'order_by=last_name&order_by_asc=asc')); ?>">&LeftDownVectorBar;</a>
										<?php else: ?>
											<a href="<?php echo e(route('admin_mentor_list', 'order_by=last_name&order_by_asc=desc')); ?>">&LeftUpVectorBar;</a>
										<?php endif; ?>
									<?php else: ?>
										<a href="<?php echo e(route('admin_mentor_list', 'order_by=last_name&order_by_asc=desc')); ?>">&LeftUpVectorBar;</a>
									<?php endif; ?>	
								</th>
								<th width="250px">Категории</th>
								<th width="250px">Страна / Город</th>
								<th align="center">E-mail</th>
								<th align="center">Телефон</th>
								<th align="center">
									Верицифирован
									<?php if($order_by == 'verified'): ?>
										<?php if($order_by_asc == 'desc'): ?>
											<a href="<?php echo e(route('admin_mentor_list', 'order_by=verified&order_by_asc=asc')); ?>">&LeftDownVectorBar;</a>
										<?php else: ?>
											<a href="<?php echo e(route('admin_mentor_list', 'order_by=verified&order_by_asc=desc')); ?>">&LeftUpVectorBar;</a>
										<?php endif; ?>
									<?php else: ?>
										<a href="<?php echo e(route('admin_mentor_list', 'order_by=verified&order_by_asc=desc')); ?>">&LeftUpVectorBar;</a>
									<?php endif; ?>
								</th>
								<th align="center">Статус аккаунта</th>
								<th width="200px" align="right">Действия</th>
							</thead>
							<tbody>
								<?php if($list->count()): ?>
									<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								
										<tr>
										
											<td><input type="checkbox" name="ids[]" value="<?php echo e($rec->id); ?>" /></td>
											<td><?php echo e($rec->id); ?></td>
											<td><a href="<?php echo e(route('admin_mentor_form', $rec->id)); ?>"><?php echo e($rec->last_name); ?> <?php echo e($rec->first_name); ?> <?php echo e($rec->surname); ?></a></td>
											<td>
												<div class="overflow_"><?php echo $rec->categories; ?></div>
											</td>
											<td><?php echo $rec->country; ?> / <?php echo $rec->city; ?></td>
											<td align="center"><a href="mailto:<?php echo e($rec->email); ?>"><?php echo e($rec->email); ?></a></td>
											<td align="center"><a href="tel:<?php echo e($rec->phone); ?>"><?php echo e($rec->phone); ?></a></td>
											<td>
												<?php if($rec->verified): ?>
													<span class="badge badge-success">Верифицирован</span>
												<?php else: ?>
													<span class="badge badge-warning">Нет</span>
												<?php endif; ?>											
											</td>
											<td>
												<?php if($rec->vip_status): ?>
													<span class="badge badge-danger">VIP</span>
												<?php else: ?>
													<span class="badge badge-info">Обычный</span>
												<?php endif; ?>
											</td>
											<td align="right">
												<a href="<?php echo e(route('admin_mentor_view', $rec->id)); ?>" class="badge badge-success"><i class="mdi mdi-eye"></i></a>
												<a href="<?php echo e(route('admin_mentor_form', $rec->id)); ?>" class="badge badge-info"><i class="remove mdi mdi-pencil"></i></a>
												<a href="<?php echo e(route('admin_delete_record', ['mentor', $rec->id])); ?>" data-confirm="Удалить ментора <?php echo e($rec->last_name); ?> <?php echo e($rec->first_name); ?>?" class="confirm badge badge-danger"><i class="remove mdi mdi-close-circle-outline"></i></a>
											</td>
											
										</tr>
								
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php else: ?>
									<tr>
										<td colspan="15">Нет информации</td>
									</tr>
								<?php endif; ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/i/indesiv4/indesiv4.beget.tech/public_html/resources/views/admin/mentor_list.blade.php ENDPATH**/ ?>