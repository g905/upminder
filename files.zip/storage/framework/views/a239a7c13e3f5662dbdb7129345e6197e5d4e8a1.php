<?php $__env->startSection('content'); ?>
  <div class="page-header">
    <h3 class="page-title">
			<span class="page-title-icon bg-gradient-primary text-white me-2">
				<i class="mdi mdi-home"></i>
			</span>
      <?php echo e($page_title); ?>

    </h3>
    <a href="<?php echo e(route('admin.mentor_services.add', 0)); ?>" class="btn btn-success">Добавить</a>
  </div>


    








  <div class="row">
    <div class="col-md-12 grid-margin">
      <?php echo $__env->make('layouts.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div class="card">
        <div class="card-body table">
          <div class="table-responsive">
            <table class="table">
              <thead>
                <th width="36px"><input type="checkbox" class="select_all" /></th>
                <th width="36px">ID</th>
                <th width="200px">Категория</th>
                <th width="250px">Тип</th>
                <th width="200px" align="right">Действия</th>
              </thead>
              <tbody>
                <?php if($services->count()): ?>
                  <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><input type="checkbox" name="ids[]" value="<?php echo e($item->id); ?>" /></td>
                      <td><?php echo e($item->id); ?></td>
                      <td>
                        <span class=" fs-6"><?php echo e($item->name); ?></span>
                      </td>
                      <td>
                        <?php if($item->type_service == '1'): ?>
                          <span class="badge badge-success">Основная услуга</span>
                        <?php else: ?>
                          <span class="badge badge-dark">Дополнительная услуга</span>
                        <?php endif; ?>
                      </td>
                      
                      <td align="right">
                        <a href="<?php echo e(route('admin.mentor_services.edit', $item->id)); ?>" class="badge badge-info">
                          <i class="remove mdi mdi-pencil"></i></a>
                        <a href="<?php echo e(route('admin.mentor_services.delete', [$item->id])); ?>" data-confirm="Удалить занятие?" class="confirm badge badge-danger">
                          <i class="remove mdi mdi-close-circle-outline"></i></a>
                      </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                  <tr>
                    <td colspan="4">Нет информации</td>
                  </tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
  <?php echo e($services->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/i/indesiv4/indesiv4.beget.tech/public_html/resources/views/admin/mentor_services/index.blade.php ENDPATH**/ ?>